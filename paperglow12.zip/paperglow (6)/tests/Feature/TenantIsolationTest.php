<?php

namespace Tests\Feature;

use App\Models\Organization;
use App\Models\User;
use App\Models\BmCustomer;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Str;
use Tests\TestCase;

class TenantIsolationTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_is_redirected_to_login(): void
    {
        $response = $this->get('/dashboard');
        $response->assertRedirect('/login');
    }

    public function test_authenticated_user_accesses_dashboard(): void
    {
        $user = User::create([
            'name' => 'Test User',
            'email' => 'test@paperglow.co.ke',
            'password' => bcrypt('password123'),
        ]);

        $org = Organization::create([
            'uuid' => (string) Str::uuid(),
            'name' => 'Acme Corp',
            'slug' => 'acme-corp',
            'billing_email' => 'acme@example.com',
            'city' => 'Nairobi',
            'county_state' => 'Nairobi County',
            'country_code' => 'KE',
            'preferred_currency' => 'KES',
            'status' => 'active',
        ]);
        $user->organizations()->attach($org->id, ['role_name' => 'owner', 'status' => 'active']);

        $response = $this->actingAs($user)
            ->withSession(['active_organization_id' => $org->id])
            ->get('/dashboard');

        $response->assertStatus(200);
    }

    public function test_tenant_scope_isolates_records(): void
    {
        $org1 = Organization::create([
            'uuid' => (string) Str::uuid(),
            'name' => 'Tenant 1',
            'slug' => 'tenant-1',
            'billing_email' => 't1@example.com',
            'city' => 'Nairobi',
            'county_state' => 'Nairobi County',
            'country_code' => 'KE',
            'preferred_currency' => 'KES',
            'status' => 'active',
        ]);

        $org2 = Organization::create([
            'uuid' => (string) Str::uuid(),
            'name' => 'Tenant 2',
            'slug' => 'tenant-2',
            'billing_email' => 't2@example.com',
            'city' => 'Nairobi',
            'county_state' => 'Nairobi County',
            'country_code' => 'KE',
            'preferred_currency' => 'KES',
            'status' => 'active',
        ]);

        session(['active_organization_id' => $org1->id]);
        BmCustomer::create([
            'organization_id' => $org1->id,
            'name' => 'Customer Org 1',
            'company' => 'Alpha Ltd',
            'phone' => '+254700000001',
            'email' => 'cust1@example.com',
        ]);

        session(['active_organization_id' => $org2->id]);
        BmCustomer::create([
            'organization_id' => $org2->id,
            'name' => 'Customer Org 2',
            'company' => 'Beta Ltd',
            'phone' => '+254700000002',
            'email' => 'cust2@example.com',
        ]);

        // When in org 1 context, only org 1 customer is accessible
        session(['active_organization_id' => $org1->id]);
        $customers1 = BmCustomer::all();
        $this->assertCount(1, $customers1);
        $this->assertEquals('Customer Org 1', $customers1->first()->name);

        // When in org 2 context, only org 2 customer is accessible
        session(['active_organization_id' => $org2->id]);
        $customers2 = BmCustomer::all();
        $this->assertCount(1, $customers2);
        $this->assertEquals('Customer Org 2', $customers2->first()->name);
    }
}
